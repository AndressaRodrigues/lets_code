# Para rodar a aplicação, insira no console:
mvn spring-boot:run

# Para acessar o endpoint

http://localhost:8080/login

Deve redirecionar para:
http://localhost:8080/swagger-ui/index.html