package ada.tech.springclasses.service.Interface;

import ada.tech.springclasses.dto.CursoDto;
import ada.tech.springclasses.model.Curso;

import java.util.List;
import java.util.Optional;

public interface CursoInterface {

    List<Curso> findAllCursos();

    Optional<Curso> findCurso(int id);

    void deleteCurso(int id);

    void createCurso(CursoDto cursoDto);

    void updateCurso(int id, CursoDto cursoDto);
}
