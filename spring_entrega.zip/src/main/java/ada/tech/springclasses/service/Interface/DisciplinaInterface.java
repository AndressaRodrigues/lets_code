package ada.tech.springclasses.service.Interface;

import ada.tech.springclasses.dto.DisciplinaDto;
import ada.tech.springclasses.model.Disciplina;

import java.util.List;
import java.util.Optional;

public interface DisciplinaInterface {

    List<Disciplina> findAllDisciplinas();

    Optional<Disciplina> findDisciplina(int id);

    void deleteDisciplina(int id);

    void createDisciplina(DisciplinaDto disciplinaDto);

    void updateDisciplina(int id, DisciplinaDto disciplinaDto);
}
