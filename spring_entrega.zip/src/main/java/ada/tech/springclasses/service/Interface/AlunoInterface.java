package ada.tech.springclasses.service.Interface;

import ada.tech.springclasses.dto.AlunoDto;
import ada.tech.springclasses.model.Aluno;

import java.util.List;
import java.util.Optional;

public interface AlunoInterface {

    List<Aluno> findAllAlunos();

    Optional<Aluno> findAluno(int id);

    void deleteAluno(int id);

    void createAluno(AlunoDto alunoDto);

    void updateAluno(int id, AlunoDto alunoDto);
}
