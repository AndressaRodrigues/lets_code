package ada.tech.springclasses.service.Implementation;

import ada.tech.springclasses.dao.DisciplinaDao;
import ada.tech.springclasses.dto.DisciplinaDto;
import ada.tech.springclasses.model.Disciplina;
import ada.tech.springclasses.service.Interface.DisciplinaInterface;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DisciplinaService implements DisciplinaInterface {
    DisciplinaDao disciplinaDao;

    public DisciplinaService(DisciplinaDao disciplinaDao) {
        this.disciplinaDao = disciplinaDao;
    }

    public List<Disciplina> findAllDisciplinas() {
        return (List<Disciplina>) disciplinaDao.findAll();
    }

    public Optional<Disciplina> findDisciplina(int id) {
        return disciplinaDao.findById(id);
    }

    public void deleteDisciplina(int id) {
        disciplinaDao.deleteById(id);
    }

    public void createDisciplina(DisciplinaDto disciplinaDto) {
        Disciplina disciplina = new Disciplina();
        disciplina.setNome(disciplinaDto.getNome());
        disciplinaDao.save(disciplina);
    }

    public void updateDisciplina(int id, DisciplinaDto disciplinaDto) {
        Disciplina disciplina = new Disciplina();
        disciplina.setId(id);
        disciplina.setNome(disciplinaDto.getNome());
        disciplinaDao.save(disciplina);
    }
}
