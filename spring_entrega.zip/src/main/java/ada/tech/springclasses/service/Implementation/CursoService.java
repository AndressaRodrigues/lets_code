package ada.tech.springclasses.service.Implementation;

import ada.tech.springclasses.dao.CursoDao;
import ada.tech.springclasses.dto.CursoDto;
import ada.tech.springclasses.model.Curso;
import ada.tech.springclasses.service.Interface.CursoInterface;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CursoService implements CursoInterface {
    CursoDao cursoDao;

    public CursoService(CursoDao cursoDao) {
        this.cursoDao = cursoDao;
    }

    public List<Curso> findAllCursos() {
        return (List<Curso>) cursoDao.findAll();
    }

    public Optional<Curso> findCurso(int id) {
        return cursoDao.findById(id);
    }

    public void deleteCurso(int id) {
        cursoDao.deleteById(id);
    }

    public void createCurso(CursoDto cursoDto) {
        Curso curso = new Curso();
        curso.setNome(cursoDto.getNome());
        curso.setDuracao(cursoDto.getDuracao());
        curso.setDescricao(cursoDto.getDescricao());
        cursoDao.save(curso);
    }

    public void updateCurso(int id, CursoDto cursoDto) {
        Curso curso = new Curso();
        curso.setId(id);
        curso.setNome(cursoDto.getNome());
        curso.setDuracao(cursoDto.getDuracao());
        curso.setDescricao(cursoDto.getDescricao());
        cursoDao.save(curso);
    }
}
