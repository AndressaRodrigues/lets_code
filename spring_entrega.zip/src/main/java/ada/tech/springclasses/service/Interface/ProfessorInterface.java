package ada.tech.springclasses.service.Interface;

import ada.tech.springclasses.dto.ProfessorDto;
import ada.tech.springclasses.model.Professor;

import java.util.List;
import java.util.Optional;

public interface ProfessorInterface {

    List<Professor> findAllProfessores();

    Optional<Professor> findProfessor(int id);

    void deleteProfessor(int id);

    void createProfessor(ProfessorDto professorDto);

    void updateProfessor(int id, ProfessorDto professorDto);
}
