package ada.tech.springclasses.service.Implementation;

import ada.tech.springclasses.dao.AlunoDao;
import ada.tech.springclasses.dto.AlunoDto;
import ada.tech.springclasses.model.Aluno;
import ada.tech.springclasses.service.Interface.AlunoInterface;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AlunoService implements AlunoInterface {

    AlunoDao alunoDao;

    public AlunoService(AlunoDao alunoDao) {
        this.alunoDao = alunoDao;
    }

    public List<Aluno> findAllAlunos() {
        return (List<Aluno>) alunoDao.findAll();
    }

    public Optional<Aluno> findAluno(int id) {
                return alunoDao.findById(id);
                
    }

    public void deleteAluno(int id) {
        alunoDao.deleteById(id);
    }

    public void createAluno(AlunoDto alunoDto) {
        Aluno aluno = new Aluno();
        aluno.setNome(alunoDto.getNome());
        aluno.setSexo(alunoDto.getSexo());
        alunoDao.save(aluno);
    }

    public void updateAluno(int id, AlunoDto alunoDto) {
        Aluno aluno = new Aluno();
        aluno.setId(id);
        aluno.setNome(alunoDto.getNome());
        aluno.setSexo(alunoDto.getSexo());
        alunoDao.save(aluno);
    }
}
