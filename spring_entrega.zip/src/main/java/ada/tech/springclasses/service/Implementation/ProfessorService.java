package ada.tech.springclasses.service.Implementation;

import ada.tech.springclasses.dao.ProfessorDao;
import ada.tech.springclasses.dto.ProfessorDto;
import ada.tech.springclasses.model.Professor;
import ada.tech.springclasses.service.Interface.ProfessorInterface;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProfessorService implements ProfessorInterface {
    ProfessorDao professorDao;

    public ProfessorService(ProfessorDao professorDao) {
        this.professorDao = professorDao;
    }

    public List<Professor> findAllProfessores() {
        return (List<Professor>) professorDao.findAll();
    }

    public Optional<Professor> findProfessor(int id) {
        return professorDao.findById(id);
    }

    public void deleteProfessor(int id) {
        professorDao.deleteById(id);
    }

    public void createProfessor(ProfessorDto professorDto) {
        final Professor professor = new Professor();
        professor.setNome(professorDto.getNome());
        professor.setTitulo(professorDto.getTitulo());
        professor.setSexo(professorDto.getSexo());
        professorDao.save(professor);
    }

    public void updateProfessor(int id, ProfessorDto professorDto) {
        final Professor professor = new Professor();
        professor.setId(id);
        professor.setNome(professorDto.getNome());
        professor.setTitulo(professorDto.getTitulo());
        professor.setSexo(professorDto.getSexo());
        professorDao.save(professor);
    }
}
