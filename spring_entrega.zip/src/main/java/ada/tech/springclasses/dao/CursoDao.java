package ada.tech.springclasses.dao;

import ada.tech.springclasses.model.Curso;


import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface CursoDao extends JpaRepository<Curso, Integer> {

}
