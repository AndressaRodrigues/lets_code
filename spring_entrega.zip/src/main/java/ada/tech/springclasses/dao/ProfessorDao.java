package ada.tech.springclasses.dao;

import ada.tech.springclasses.model.Professor;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface ProfessorDao extends JpaRepository<Professor, Integer> {

}
