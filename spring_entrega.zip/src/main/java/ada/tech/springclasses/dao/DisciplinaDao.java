package ada.tech.springclasses.dao;

import ada.tech.springclasses.model.Disciplina;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface DisciplinaDao extends JpaRepository<Disciplina, Integer> {

}
