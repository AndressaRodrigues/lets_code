package ada.tech.springclasses.dto;

import ada.tech.springclasses.model.Aluno;
import ada.tech.springclasses.model.Disciplina;
import lombok.*;

import java.util.List;

@Data
@Builder
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class AlunoDto {

    private String nome;
    private char sexo;

    public static AlunoDto from (Aluno aluno) {
        final AlunoDtoBuilder alunoDtoBuilder = new AlunoDtoBuilder();
        alunoDtoBuilder.nome = aluno.getNome();
        alunoDtoBuilder.sexo = aluno.getSexo();
        return alunoDtoBuilder.build();
    }

    @Override
    public String toString() {
        return "O meu nome é: " + nome;
    }

}
