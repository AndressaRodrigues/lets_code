package ada.tech.springclasses.dto;

import ada.tech.springclasses.model.Disciplina;
import lombok.*;

@Data
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DisciplinaDto {
    private String nome;

    public static DisciplinaDto from (Disciplina disciplina) {;
        final DisciplinaDtoBuilder disciplinaDtoBuilder = new DisciplinaDtoBuilder();
        disciplinaDtoBuilder.nome = disciplina.getNome();
        return disciplinaDtoBuilder.build();
    }
}