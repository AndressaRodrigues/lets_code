package ada.tech.springclasses.model;

import lombok.*;

import javax.persistence.*;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@ToString
public class Disciplina {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String nome;
    @ManyToOne(fetch = FetchType.EAGER)
    private Curso curso;
    @ManyToMany
    private List<Professor> professores;
    @OneToMany(mappedBy = "disciplina")
    private List<Aluno> alunos;

}
