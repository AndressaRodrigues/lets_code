package ada.tech.springclasses.rest;

import ada.tech.springclasses.dto.ProfessorDto;
import ada.tech.springclasses.service.Implementation.ProfessorService;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.server.ResponseStatusException;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/professor")
public class ProfessorRest {

    private static final String ResponseEntity = null;
    private ProfessorService professorService;

    public ProfessorRest(ProfessorService professorService) {
        this.professorService = professorService;
    }

    @GetMapping
    public List<ProfessorDto> buscarProfessores() {
        return professorService.findAllProfessores().stream().map(ProfessorDto::from).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ProfessorDto encontrarProfessor(@PathVariable final int id) {
        return ProfessorDto.from(professorService.findProfessor(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Professor não encontrado")));
    }

    @PostMapping
    @Transactional
    public ResponseEntity criarProfessor(@RequestBody final ProfessorDto professorDto) {
        try {
            professorService.createProfessor(professorDto);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.CREATED);
        } catch (HttpServerErrorException e) {
            return (ResponseEntity) ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity apagarProfessor(@PathVariable final int id) {
        try {
            professorService.deleteProfessor(id);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NO_CONTENT);
            
        } catch (HttpServerErrorException e) {
            return (ResponseEntity) ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    @Transactional
    public ResponseEntity atualizarProfessor(@PathVariable final int id, @RequestBody final ProfessorDto professorDto) {
        try {
            professorService.updateProfessor(id, professorDto);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NO_CONTENT); 
        } catch (ResponseStatusException e) {
           
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NOT_FOUND);
        }
    }

}
