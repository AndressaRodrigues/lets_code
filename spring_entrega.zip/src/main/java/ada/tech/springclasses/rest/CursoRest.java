package ada.tech.springclasses.rest;

import ada.tech.springclasses.dto.CursoDto;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.server.ResponseStatusException;

import ada.tech.springclasses.service.Implementation.CursoService;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/curso")
public class CursoRest {

    private CursoService CursoService;

    public CursoRest(CursoService CursoService) {
        this.CursoService = CursoService;
    }

    @GetMapping
    public List<CursoDto> buscarCursos() {
        return CursoService.findAllCursos().stream().map(CursoDto::from).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public CursoDto encontrarCurso(@PathVariable final int id) {
        return CursoDto.from(CursoService.findCurso(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Aluno não encontrado")));
    }

    @PostMapping
    @Transactional
    public ResponseEntity criarCurso(@RequestBody final CursoDto cursoDto) {
        try {
            CursoService.createCurso(cursoDto);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.CREATED);
        } catch (HttpServerErrorException e) {
            return (ResponseEntity) ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity apagarCurso(@PathVariable final int id) {
        try {
            CursoService.deleteCurso(id);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NO_CONTENT);
        
        } catch (HttpServerErrorException e) {
            return (ResponseEntity) ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    @Transactional
    public ResponseEntity atualizarCurso(@PathVariable final int id, @RequestBody final CursoDto cursoDto) {
        try {
            CursoService.updateCurso(id, cursoDto);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NO_CONTENT); 
        } catch (ResponseStatusException e) {
           
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NOT_FOUND);
        }
    }

}
