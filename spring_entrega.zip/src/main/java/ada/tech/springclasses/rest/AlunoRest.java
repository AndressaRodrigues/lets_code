package ada.tech.springclasses.rest;

import ada.tech.springclasses.dto.AlunoDto;
import ada.tech.springclasses.service.Implementation.AlunoService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.server.ResponseStatusException;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/aluno")
public class AlunoRest {

    private AlunoService alunoService;

    public AlunoRest(AlunoService alunoService) {
        this.alunoService = alunoService;
    }

    @GetMapping
    public List<AlunoDto> buscarAlunos() {
        return alunoService.findAllAlunos().stream().map(AlunoDto::from).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public AlunoDto encontrarAluno(@PathVariable final int id) {
     
        return AlunoDto.from(alunoService.findAluno(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Aluno não encontrado")));
        
    }

    @PostMapping
    @Transactional
    public ResponseEntity criarAluno(@RequestBody final AlunoDto alunoDto) {
        try {

           alunoService.createAluno(alunoDto);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.CREATED);
        } catch (HttpServerErrorException e) {
            return (ResponseEntity) ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
       
    }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity apagarAluno(@PathVariable final int id) {
        try {
            alunoService.deleteAluno(id);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NO_CONTENT);
        
        } catch (HttpServerErrorException e) {
            return (ResponseEntity) ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    @Transactional
    public  ResponseEntity atualizarAluno(@PathVariable final int id, @RequestBody final AlunoDto alunoDto) {
        try {
            alunoService.updateAluno(id, alunoDto);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NO_CONTENT); 
        } catch (ResponseStatusException e) {
           
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NOT_FOUND);
        }
    }

}
