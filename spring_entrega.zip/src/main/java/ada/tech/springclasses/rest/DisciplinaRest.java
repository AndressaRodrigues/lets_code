package ada.tech.springclasses.rest;

import ada.tech.springclasses.dto.DisciplinaDto;
import ada.tech.springclasses.service.Implementation.DisciplinaService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.server.ResponseStatusException;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/disciplina")
public class DisciplinaRest {

    private DisciplinaService disciplinaService;

    public DisciplinaRest(DisciplinaService disciplinaService) {
        this.disciplinaService = disciplinaService;
    }

    @GetMapping
    public List<DisciplinaDto> buscarDisciplinas() {
        return disciplinaService.findAllDisciplinas().stream().map(DisciplinaDto::from).collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public DisciplinaDto encontrarDisciplina(@PathVariable final int id) {
        return DisciplinaDto.from(disciplinaService.findDisciplina(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Aluno não encontrado")));
    }

    @PostMapping
    @Transactional
    public ResponseEntity criarDisciplina(@RequestBody final DisciplinaDto disciplinaDto) {
        try {
            disciplinaService.createDisciplina(disciplinaDto);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.CREATED);
        } catch (HttpServerErrorException e) {
            return (ResponseEntity) ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        }

    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity apagarDisciplina(@PathVariable final int id) {
        try {
            disciplinaService.deleteDisciplina(id);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NO_CONTENT);
        
        } catch (HttpServerErrorException e) {
            return (ResponseEntity) ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    @Transactional
    public ResponseEntity atualizarDisciplina(@PathVariable final int id, @RequestBody final DisciplinaDto disciplinaDto) {
        try {
            disciplinaService.updateDisciplina(id, disciplinaDto);
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NO_CONTENT); 
        } catch (ResponseStatusException e) {
           
            return (ResponseEntity) ResponseEntity.status(HttpStatus.NOT_FOUND);
        }
    }

}
