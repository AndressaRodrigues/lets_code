insert into aluno (nome, sexo) values ('Nuno', 'm');
insert into aluno (nome, sexo) values ('Ana', 'f');
insert into aluno (nome, sexo) values ('Mario', 'm');