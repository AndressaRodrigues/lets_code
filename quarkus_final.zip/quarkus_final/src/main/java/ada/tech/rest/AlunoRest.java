package ada.tech.rest;

import ada.tech.dto.AlunoDto;
import ada.tech.service.AlunoService;
import io.quarkus.logging.Log;

import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.xml.bind.DataBindingException;

import org.hibernate.exception.DataException;

import java.util.List;
import java.util.stream.Collectors;


@Path("/aluno")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AlunoRest {

    private AlunoService alunoService = new AlunoService();

    @GET
    public List<AlunoDto> buscarAlunos() {
        return alunoService.findAllAlunos().stream().map(AlunoDto::from).collect(Collectors.toList());
    }

    @GET
    @Path("/{id}")
    public Response encontrarAluno(@PathParam("id") final int id) {
        
          try {

              return Response.ok(AlunoDto.from(alunoService.findAluno(id))).build();
          } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.NOT_FOUND).build();
          }
          
    }

    @POST
    @Transactional
    public Response criarAluno(final AlunoDto alunoDto) {
        try {
            alunoService.createAluno(alunoDto);
            return Response.status(Status.CREATED).build();
        } catch (DataException e) {
            Log.info(e);
            return Response.status(Status.NOT_IMPLEMENTED).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DELETE
    @Transactional
    @Path("/{id}")
    public Response apagarAluno(@PathParam("id") int id) {
        try {
            alunoService.deleteAluno(id);
            return Response.status(Status.NO_CONTENT).build();
        } catch (NullPointerException e) {
            Log.info(e);
            return Response.status(Status.NOT_FOUND).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PUT
    @Transactional
    @Path("/{id}")
    public Response atualizarAluno(@PathParam("id") int id, final AlunoDto alunoDto) {
       try {
            alunoService.updateAluno(id, alunoDto);
            return Response.status(Status. NO_CONTENT).build();
        } catch (NullPointerException e) {
            Log.info(e);
            return Response.status(Status.NOT_FOUND).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

}
