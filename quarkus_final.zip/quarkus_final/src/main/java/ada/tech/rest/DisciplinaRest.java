package ada.tech.rest;

import ada.tech.dto.DisciplinaDto;
import ada.tech.service.DisciplinaService;
import io.quarkus.logging.Log;

import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.hibernate.exception.DataException;

import java.util.List;
import java.util.stream.Collectors;


@Path("/disciplina")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class DisciplinaRest {

    private DisciplinaService disciplinaService = new DisciplinaService();

    @GET
    public List<DisciplinaDto> buscarDisciplinas() {
        return disciplinaService.findAllDisciplinas().stream().map(DisciplinaDto::from).collect(Collectors.toList());
    }

    @GET
    @Path("/{id}")
    public Response encontrarDisciplina(@PathParam("id") final int id) {
        try {
            return Response.ok(DisciplinaDto.from(disciplinaService.findDisciplina(id))).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    @POST
    @Transactional
    public Response criarDisciplina(final DisciplinaDto disciplinaDto) {
        try {
            disciplinaService.createDisciplina(disciplinaDto);
            return Response.status(Status.CREATED).build();
        } catch (DataException e) {
            Log.info(e);
            return Response.status(Status.NOT_IMPLEMENTED).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DELETE
    @Transactional
    @Path("/{id}")
    public Response apagarDisciplina(@PathParam("id") int id) {
        try {
            disciplinaService.deleteDisciplina(id);
            return Response.status(Status.NO_CONTENT).build();
        } catch (NullPointerException e) {
            Log.info(e);
            return Response.status(Status.NOT_FOUND).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PUT
    @Transactional
    @Path("/{id}")
    public Response atualizarDisciplina(@PathParam("id") int id, final DisciplinaDto disciplinaDto) {
        try {
            disciplinaService.updateDisciplina(id, disciplinaDto);
            return Response.status(Status. NO_CONTENT).build();

        } catch (NullPointerException e) {
            Log.info(e);
            return Response.status(Status.NOT_FOUND).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

}
