package ada.tech.rest;

import ada.tech.dto.CursoDto;
import ada.tech.service.CursoService;
import io.quarkus.logging.Log;

import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.hibernate.exception.DataException;

import java.util.List;
import java.util.stream.Collectors;


@Path("/curso")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CursoRest {

    private CursoService cursoService = new CursoService();

    @GET
    public List<CursoDto> buscarCursos() {
        return cursoService.findAllCursos().stream().map(CursoDto::from).collect(Collectors.toList());
    }

    @GET
    @Path("/{id}")
    public Response encontrarCurso(@PathParam("id") final int id) {
        try {
           return Response.ok(CursoDto.from(cursoService.findCurso(id))).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    @POST
    @Transactional
    public Response criarCurso(final CursoDto cursoDto) {
        try {
            cursoService.createCurso(cursoDto);
            return Response.status(Status.CREATED).build();
        } catch (DataException e) {
            Log.info(e);
            return Response.status(Status.NOT_IMPLEMENTED).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DELETE
    @Transactional
    @Path("/{id}")
    public Response apagarCurso(@PathParam("id") int id) {
        try {
            cursoService.deleteCurso(id);
            return Response.status(Status.NO_CONTENT).build();
        } catch (NullPointerException e) {
            Log.info(e);
            return Response.status(Status.NOT_FOUND).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PUT
    @Transactional
    @Path("/{id}")
    public Response atualizarCurso(@PathParam("id") int id, final CursoDto CursoDto) {
        try {    
            cursoService.updateCurso(id, CursoDto);
            return Response.status(Status. NO_CONTENT).build();

        } catch (NullPointerException e) {
            Log.info(e);
            return Response.status(Status.NOT_FOUND).build();
        } catch (Exception e) {
            Log.info(e);
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

}
