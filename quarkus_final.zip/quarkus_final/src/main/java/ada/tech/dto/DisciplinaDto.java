package ada.tech.dto;


import ada.tech.model.Disciplina;
import lombok.*;

@Getter
@Builder
@AllArgsConstructor
public class DisciplinaDto {
    private String nome;

    public static DisciplinaDto from (Disciplina disciplina) {;
        final DisciplinaDtoBuilder disciplinaDtoBuilder = new DisciplinaDtoBuilder();
        disciplinaDtoBuilder.nome = disciplina.getNome();
        return disciplinaDtoBuilder.build();
    }
}